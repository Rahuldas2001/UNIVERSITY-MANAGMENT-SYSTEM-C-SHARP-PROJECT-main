﻿
namespace AiubManagementSystem
{
    partial class Support_Staff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTDelete = new System.Windows.Forms.Button();
            this.btnTEdit = new System.Windows.Forms.Button();
            this.btnTAdd = new System.Windows.Forms.Button();
            this.txtDesignation = new System.Windows.Forms.TextBox();
            this.cmbGender = new System.Windows.Forms.ComboBox();
            this.txtSSname = new System.Windows.Forms.TextBox();
            this.txtSSid = new System.Windows.Forms.TextBox();
            this.lblTDepertment = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewStaff = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.btnSback = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Salary = new System.Windows.Forms.Label();
            this.txtSalary = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaff)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnTDelete
            // 
            this.btnTDelete.BackColor = System.Drawing.Color.Violet;
            this.btnTDelete.FlatAppearance.BorderSize = 0;
            this.btnTDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTDelete.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTDelete.Location = new System.Drawing.Point(201, 500);
            this.btnTDelete.Name = "btnTDelete";
            this.btnTDelete.Size = new System.Drawing.Size(85, 39);
            this.btnTDelete.TabIndex = 56;
            this.btnTDelete.Text = "Delete";
            this.btnTDelete.UseVisualStyleBackColor = false;
            this.btnTDelete.Click += new System.EventHandler(this.btnTDelete_Click);
            // 
            // btnTEdit
            // 
            this.btnTEdit.BackColor = System.Drawing.Color.Violet;
            this.btnTEdit.FlatAppearance.BorderSize = 0;
            this.btnTEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTEdit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTEdit.Location = new System.Drawing.Point(109, 500);
            this.btnTEdit.Name = "btnTEdit";
            this.btnTEdit.Size = new System.Drawing.Size(86, 39);
            this.btnTEdit.TabIndex = 55;
            this.btnTEdit.Text = "Edit";
            this.btnTEdit.UseVisualStyleBackColor = false;
            this.btnTEdit.Click += new System.EventHandler(this.btnTEdit_Click);
            // 
            // btnTAdd
            // 
            this.btnTAdd.BackColor = System.Drawing.Color.Violet;
            this.btnTAdd.FlatAppearance.BorderSize = 0;
            this.btnTAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnTAdd.Location = new System.Drawing.Point(28, 500);
            this.btnTAdd.Name = "btnTAdd";
            this.btnTAdd.Size = new System.Drawing.Size(75, 39);
            this.btnTAdd.TabIndex = 54;
            this.btnTAdd.Text = "Add";
            this.btnTAdd.UseVisualStyleBackColor = false;
            this.btnTAdd.Click += new System.EventHandler(this.btnTAdd_Click);
            // 
            // txtDesignation
            // 
            this.txtDesignation.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtDesignation.Location = new System.Drawing.Point(123, 370);
            this.txtDesignation.Multiline = true;
            this.txtDesignation.Name = "txtDesignation";
            this.txtDesignation.Size = new System.Drawing.Size(155, 32);
            this.txtDesignation.TabIndex = 51;
            // 
            // cmbGender
            // 
            this.cmbGender.ForeColor = System.Drawing.Color.Black;
            this.cmbGender.FormattingEnabled = true;
            this.cmbGender.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.cmbGender.Location = new System.Drawing.Point(121, 313);
            this.cmbGender.Name = "cmbGender";
            this.cmbGender.Size = new System.Drawing.Size(155, 24);
            this.cmbGender.TabIndex = 47;
            // 
            // txtSSname
            // 
            this.txtSSname.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtSSname.Location = new System.Drawing.Point(123, 249);
            this.txtSSname.Multiline = true;
            this.txtSSname.Name = "txtSSname";
            this.txtSSname.Size = new System.Drawing.Size(155, 32);
            this.txtSSname.TabIndex = 46;
            // 
            // txtSSid
            // 
            this.txtSSid.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtSSid.Location = new System.Drawing.Point(123, 178);
            this.txtSSid.Multiline = true;
            this.txtSSid.Name = "txtSSid";
            this.txtSSid.Size = new System.Drawing.Size(155, 32);
            this.txtSSid.TabIndex = 45;
            // 
            // lblTDepertment
            // 
            this.lblTDepertment.AutoSize = true;
            this.lblTDepertment.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTDepertment.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblTDepertment.Location = new System.Drawing.Point(8, 382);
            this.lblTDepertment.Name = "lblTDepertment";
            this.lblTDepertment.Size = new System.Drawing.Size(109, 20);
            this.lblTDepertment.TabIndex = 43;
            this.lblTDepertment.Text = "Designation";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.SteelBlue;
            this.label6.Location = new System.Drawing.Point(25, 313);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 20);
            this.label6.TabIndex = 42;
            this.label6.Text = "Gender";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SteelBlue;
            this.label5.Location = new System.Drawing.Point(37, 261);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 41;
            this.label5.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Location = new System.Drawing.Point(63, 190);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 20);
            this.label4.TabIndex = 40;
            this.label4.Text = "Id";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.SteelBlue;
            this.label11.Font = new System.Drawing.Font("SketchFlow Print", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(572, 143);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(168, 32);
            this.label11.TabIndex = 39;
            this.label11.Text = "Staff List";
            // 
            // dataGridViewStaff
            // 
            this.dataGridViewStaff.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewStaff.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStaff.Location = new System.Drawing.Point(303, 178);
            this.dataGridViewStaff.Name = "dataGridViewStaff";
            this.dataGridViewStaff.RowHeadersWidth = 51;
            this.dataGridViewStaff.RowTemplate.Height = 24;
            this.dataGridViewStaff.Size = new System.Drawing.Size(731, 305);
            this.dataGridViewStaff.TabIndex = 38;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.btnSback);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1041, 109);
            this.panel1.TabIndex = 63;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Red;
            this.button8.Location = new System.Drawing.Point(981, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 32);
            this.button8.TabIndex = 76;
            this.button8.Text = "X";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnSback
            // 
            this.btnSback.BackColor = System.Drawing.Color.Red;
            this.btnSback.FlatAppearance.BorderSize = 0;
            this.btnSback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSback.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSback.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSback.Location = new System.Drawing.Point(0, 0);
            this.btnSback.Name = "btnSback";
            this.btnSback.Size = new System.Drawing.Size(71, 32);
            this.btnSback.TabIndex = 22;
            this.btnSback.Text = "Back";
            this.btnSback.UseVisualStyleBackColor = false;
            this.btnSback.Click += new System.EventHandler(this.btnSback_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Tomato;
            this.label3.Location = new System.Drawing.Point(363, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(313, 44);
            this.label3.TabIndex = 15;
            this.label3.Text = "Support Staff";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("SketchFlow Print", 22.2F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(385, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(418, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("SketchFlow Print", 22.2F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(273, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "AIUB";
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Salary.ForeColor = System.Drawing.Color.SteelBlue;
            this.Salary.Location = new System.Drawing.Point(25, 447);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(62, 20);
            this.Salary.TabIndex = 64;
            this.Salary.Text = "Salary";
            // 
            // txtSalary
            // 
            this.txtSalary.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtSalary.Location = new System.Drawing.Point(121, 435);
            this.txtSalary.Multiline = true;
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(155, 32);
            this.txtSalary.TabIndex = 65;
            // 
            // Support_Staff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 625);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnTDelete);
            this.Controls.Add(this.btnTEdit);
            this.Controls.Add(this.btnTAdd);
            this.Controls.Add(this.txtDesignation);
            this.Controls.Add(this.cmbGender);
            this.Controls.Add(this.txtSSname);
            this.Controls.Add(this.txtSSid);
            this.Controls.Add(this.lblTDepertment);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dataGridViewStaff);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Support_Staff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Support_Staff";
            this.Load += new System.EventHandler(this.Support_Staff_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStaff)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnTDelete;
        private System.Windows.Forms.Button btnTEdit;
        private System.Windows.Forms.Button btnTAdd;
        private System.Windows.Forms.TextBox txtDesignation;
        private System.Windows.Forms.ComboBox cmbGender;
        private System.Windows.Forms.TextBox txtSSname;
        private System.Windows.Forms.TextBox txtSSid;
        private System.Windows.Forms.Label lblTDepertment;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewStaff;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSback;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.TextBox txtSalary;
    }
}