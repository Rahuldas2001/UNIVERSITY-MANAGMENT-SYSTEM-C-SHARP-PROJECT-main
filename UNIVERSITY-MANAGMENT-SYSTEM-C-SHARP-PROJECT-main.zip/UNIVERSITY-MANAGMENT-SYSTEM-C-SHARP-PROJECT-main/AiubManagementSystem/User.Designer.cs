﻿
namespace AiubManagementSystem
{
    partial class User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSback = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnUDelete = new System.Windows.Forms.Button();
            this.btnUEdit = new System.Windows.Forms.Button();
            this.btnUAdd = new System.Windows.Forms.Button();
            this.txtUpassword = new System.Windows.Forms.TextBox();
            this.txtUname = new System.Windows.Forms.TextBox();
            this.txtUid = new System.Windows.Forms.TextBox();
            this.lblTphone = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.dataGridViewUser = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUser)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.btnSback);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(946, 105);
            this.panel1.TabIndex = 4;
            // 
            // btnSback
            // 
            this.btnSback.BackColor = System.Drawing.Color.Red;
            this.btnSback.FlatAppearance.BorderSize = 0;
            this.btnSback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSback.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSback.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnSback.Location = new System.Drawing.Point(0, -1);
            this.btnSback.Name = "btnSback";
            this.btnSback.Size = new System.Drawing.Size(71, 32);
            this.btnSback.TabIndex = 22;
            this.btnSback.Text = "Back";
            this.btnSback.UseVisualStyleBackColor = false;
            this.btnSback.Click += new System.EventHandler(this.btnSback_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Red;
            this.button8.Location = new System.Drawing.Point(886, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 32);
            this.button8.TabIndex = 16;
            this.button8.Text = "X";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Tomato;
            this.label3.Location = new System.Drawing.Point(350, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 49);
            this.label3.TabIndex = 15;
            this.label3.Text = "Users";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("SketchFlow Print", 22.2F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(306, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(418, 41);
            this.label2.TabIndex = 2;
            this.label2.Text = "Management System";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("SketchFlow Print", 22.2F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(194, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 41);
            this.label1.TabIndex = 1;
            this.label1.Text = "AIUB";
            // 
            // btnUDelete
            // 
            this.btnUDelete.BackColor = System.Drawing.Color.Violet;
            this.btnUDelete.FlatAppearance.BorderSize = 0;
            this.btnUDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUDelete.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUDelete.Location = new System.Drawing.Point(220, 512);
            this.btnUDelete.Name = "btnUDelete";
            this.btnUDelete.Size = new System.Drawing.Size(90, 39);
            this.btnUDelete.TabIndex = 56;
            this.btnUDelete.Text = "Delete";
            this.btnUDelete.UseVisualStyleBackColor = false;
            this.btnUDelete.Click += new System.EventHandler(this.btnUDelete_Click);
            // 
            // btnUEdit
            // 
            this.btnUEdit.BackColor = System.Drawing.Color.Violet;
            this.btnUEdit.FlatAppearance.BorderSize = 0;
            this.btnUEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUEdit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUEdit.Location = new System.Drawing.Point(119, 512);
            this.btnUEdit.Name = "btnUEdit";
            this.btnUEdit.Size = new System.Drawing.Size(75, 39);
            this.btnUEdit.TabIndex = 55;
            this.btnUEdit.Text = "Edit";
            this.btnUEdit.UseVisualStyleBackColor = false;
            this.btnUEdit.Click += new System.EventHandler(this.btnUEdit_Click);
            // 
            // btnUAdd
            // 
            this.btnUAdd.BackColor = System.Drawing.Color.Violet;
            this.btnUAdd.FlatAppearance.BorderSize = 0;
            this.btnUAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUAdd.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUAdd.Location = new System.Drawing.Point(23, 512);
            this.btnUAdd.Name = "btnUAdd";
            this.btnUAdd.Size = new System.Drawing.Size(75, 39);
            this.btnUAdd.TabIndex = 54;
            this.btnUAdd.Text = "Add";
            this.btnUAdd.UseVisualStyleBackColor = false;
            this.btnUAdd.Click += new System.EventHandler(this.btnUAdd_Click);
            // 
            // txtUpassword
            // 
            this.txtUpassword.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtUpassword.Location = new System.Drawing.Point(119, 372);
            this.txtUpassword.Multiline = true;
            this.txtUpassword.Name = "txtUpassword";
            this.txtUpassword.Size = new System.Drawing.Size(155, 32);
            this.txtUpassword.TabIndex = 49;
            // 
            // txtUname
            // 
            this.txtUname.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtUname.Location = new System.Drawing.Point(119, 312);
            this.txtUname.Multiline = true;
            this.txtUname.Name = "txtUname";
            this.txtUname.Size = new System.Drawing.Size(155, 32);
            this.txtUname.TabIndex = 46;
            // 
            // txtUid
            // 
            this.txtUid.ForeColor = System.Drawing.Color.SteelBlue;
            this.txtUid.Location = new System.Drawing.Point(119, 247);
            this.txtUid.Multiline = true;
            this.txtUid.Name = "txtUid";
            this.txtUid.Size = new System.Drawing.Size(155, 32);
            this.txtUid.TabIndex = 45;
            // 
            // lblTphone
            // 
            this.lblTphone.AutoSize = true;
            this.lblTphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTphone.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblTphone.Location = new System.Drawing.Point(7, 384);
            this.lblTphone.Name = "lblTphone";
            this.lblTphone.Size = new System.Drawing.Size(91, 20);
            this.lblTphone.TabIndex = 44;
            this.lblTphone.Text = "Password";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SteelBlue;
            this.label5.Location = new System.Drawing.Point(31, 324);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 41;
            this.label5.Text = "Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.SteelBlue;
            this.label4.Location = new System.Drawing.Point(51, 259);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(24, 20);
            this.label4.TabIndex = 40;
            this.label4.Text = "Id";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.SteelBlue;
            this.label11.Font = new System.Drawing.Font("SketchFlow Print", 22.2F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.Transparent;
            this.label11.Location = new System.Drawing.Point(564, 136);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(223, 41);
            this.label11.TabIndex = 39;
            this.label11.Text = "Users List";
            // 
            // dataGridViewUser
            // 
            this.dataGridViewUser.AllowUserToAddRows = false;
            this.dataGridViewUser.AllowUserToDeleteRows = false;
            this.dataGridViewUser.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewUser.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewUser.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewUser.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridViewUser.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dataGridViewUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUser.GridColor = System.Drawing.Color.SteelBlue;
            this.dataGridViewUser.Location = new System.Drawing.Point(487, 190);
            this.dataGridViewUser.Name = "dataGridViewUser";
            this.dataGridViewUser.ReadOnly = true;
            this.dataGridViewUser.RowHeadersWidth = 51;
            this.dataGridViewUser.RowTemplate.Height = 24;
            this.dataGridViewUser.Size = new System.Drawing.Size(373, 305);
            this.dataGridViewUser.TabIndex = 38;
            // 
            // User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 612);
            this.Controls.Add(this.btnUDelete);
            this.Controls.Add(this.btnUEdit);
            this.Controls.Add(this.btnUAdd);
            this.Controls.Add(this.txtUpassword);
            this.Controls.Add(this.txtUname);
            this.Controls.Add(this.txtUid);
            this.Controls.Add(this.lblTphone);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dataGridViewUser);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "User";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User";
            this.Load += new System.EventHandler(this.User_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnUDelete;
        private System.Windows.Forms.Button btnUEdit;
        private System.Windows.Forms.Button btnUAdd;
        private System.Windows.Forms.TextBox txtUpassword;
        private System.Windows.Forms.TextBox txtUname;
        private System.Windows.Forms.TextBox txtUid;
        private System.Windows.Forms.Label lblTphone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridViewUser;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnSback;
    }
}